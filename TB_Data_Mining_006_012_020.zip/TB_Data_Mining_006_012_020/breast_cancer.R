lokasi_kerja <- "E:/TB_Data_Mining_006_012_020"
getwd()
setwd(lokasi_kerja)
getwd()
dataset <- read.csv("breast_cancer.csv", sep = ",")
install.packages("C50")
install.packages("printr")
library(C50)
library(printr)
model <- C5.0(classification ~., data=dataset)
model
summary(model)
plot(model)
datatesting <- dataset[,1:9]
predictions <- predict(model, datatesting)
table(predictions, dataset$classification)
